#ifndef ASSEMBLERH
#define ASSEMBLERH

#include "Sifter.h"
#include "Janitor.h"
#include "Static.h"
#include "Instruction_t.h"
#include "Config.h"
#include "IO.h"
#include "Multi_Store.h"

#endif