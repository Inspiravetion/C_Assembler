#include "Garbage.h"


bool GARBAGE_INITIALIZED = false;
int GARBAGE_CAPACITY = 0;
int GARBAGE_COUNT = 0;
void** GARBAGE = NULL;
